program pprinting;

uses
  Forms,
  printing in 'printing.pas' {Labeldruck},
  Utilities in '..\common\Utilities.pas';

{$R *.res}

begin
  Application.Initialize;
  Application.CreateForm(TLabeldruck, Labeldruck);
  Application.Run;
end.
